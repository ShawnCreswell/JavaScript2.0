function hide(element, element2, element3){
    element.remove()
    element2.innerText++
    element3.innerText--
}

function hide2(element, element2){
    element.remove()
    element2.innerText--
}

function change(element) {
    element.innerText = "Billy Jean"
}

// function likes(element) {
//     element.innerText++;
// }